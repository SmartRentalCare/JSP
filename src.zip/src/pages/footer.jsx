export default function footer() {
  return (
    <div className="footerpart">
      <div>@rentcare</div>
      <div>졸업시켜죠</div>
      <div>회사소개</div>
      <div>개인정보처리방침</div>

      <div>이용약관</div>
    </div>
  );
}
